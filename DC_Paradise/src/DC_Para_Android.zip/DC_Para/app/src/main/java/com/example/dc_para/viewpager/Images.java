package com.example.dc_para.viewpager;

import com.example.dc_para.R;

public class Images {
    public static final int[] imageArray = new int[]{
            R.drawable.vp_images01,
            R.drawable.vp_images02,
            R.drawable.vp_images03,
            R.drawable.vp_images04,
    };
}
